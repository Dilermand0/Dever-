package Negocio;

import javax.swing.JOptionPane;

import Modelagem.Usuario;

public class Armazenamento {
    private Usuario usuario;

    public void adicionarUsuario(String cpf) {
        usuario = new Usuario();
        usuario.setCpf(cpf);
        JOptionPane.showMessageDialog(null, "CPF armazenado com sucesso: " + cpf);
    }
}