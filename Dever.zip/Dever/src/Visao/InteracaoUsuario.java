package Visao;

import javax.swing.JOptionPane;

import Negocio.Armazenamento;

public class InteracaoUsuario {
    public static void main(String[] args) {
        Armazenamento armazenamento = new Armazenamento();

        String cpf = JOptionPane.showInputDialog("Por favor, insira o seu CPF:");
        armazenamento.adicionarUsuario(cpf);
    }
}